const API_BASE = "http://localhost:5002/api";

let resumes = []; // {name, text}

const jobDescriptionEl = document.getElementById("jobDescription");
const resumeFilesInput = document.getElementById("resumeFiles");
const resumeListEl = document.getElementById("resumeList");
const statusEl = document.getElementById("status");

document.getElementById("loadSampleBtn").addEventListener("click", loadSample);
document.getElementById("screenBtn").addEventListener("click", screenCandidates);
resumeFilesInput.addEventListener("change", handleFileUpload);

async function loadSample() {
  statusEl.textContent = "Loading sample data...";
  try {
    const res = await fetch(`${API_BASE}/sample-data`);
    const json = await res.json();
    jobDescriptionEl.value = json.job_description;
    resumes = json.resumes;
    renderResumeList();
    statusEl.textContent = `Loaded job description + ${resumes.length} sample resumes.`;
  } catch (err) {
    statusEl.textContent = "Could not reach backend. Is the Flask server running on port 5002?";
  }
}

async function handleFileUpload(e) {
  const files = Array.from(e.target.files);
  for (const file of files) {
    const text = await file.text();
    resumes.push({ name: file.name, text });
  }
  renderResumeList();
  resumeFilesInput.value = "";
}

function renderResumeList() {
  resumeListEl.innerHTML = "";
  resumes.forEach((r, idx) => {
    const div = document.createElement("div");
    div.className = "resume-item";
    div.innerHTML = `<span>${r.name}</span>`;
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", () => {
      resumes.splice(idx, 1);
      renderResumeList();
    });
    div.appendChild(removeBtn);
    resumeListEl.appendChild(div);
  });
}

async function screenCandidates() {
  const jobDescription = jobDescriptionEl.value.trim();
  if (!jobDescription) {
    statusEl.textContent = "Please provide a job description.";
    return;
  }
  if (resumes.length === 0) {
    statusEl.textContent = "Add at least one resume (upload files or load sample data).";
    return;
  }
  statusEl.textContent = "Screening candidates...";
  try {
    const res = await fetch(`${API_BASE}/screen`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ job_description: jobDescription, resumes }),
    });
    const json = await res.json();
    if (json.error) throw new Error(json.error);
    renderRequiredSkills(json.required_skills);
    renderResults(json.candidates);
    statusEl.textContent = `Ranked ${json.candidates.length} candidate(s).`;
  } catch (err) {
    statusEl.textContent = `Error: ${err.message}`;
  }
}

function renderRequiredSkills(skills) {
  const container = document.getElementById("requiredSkills");
  container.innerHTML = "";
  skills.forEach((s) => {
    const tag = document.createElement("span");
    tag.className = "skill-tag";
    tag.textContent = s;
    container.appendChild(tag);
  });
  document.getElementById("requiredSkillsCard").style.display = skills.length ? "block" : "none";
}

function renderResults(candidates) {
  const container = document.getElementById("results");
  container.innerHTML = "";
  candidates.forEach((c) => {
    const card = document.createElement("div");
    card.className = "candidate-card";
    card.innerHTML = `
      <div class="candidate-header">
        <h3><span class="rank-badge">#${c.rank}</span>${c.name}</h3>
        <span class="score-badge">${c.final_score_pct}%</span>
      </div>
      <div class="score-bar-bg"><div class="score-bar-fill" style="width:${c.final_score_pct}%"></div></div>
      <p class="muted">Skill overlap: ${c.skill_overlap_pct}% · Text similarity: ${c.text_similarity_pct}%</p>
      <div class="skills-row">
        <div class="skills-col">
          <h4>Matched Skills</h4>
          ${c.matched_skills.length ? c.matched_skills.map((s) => `<span class="tag-good">✓ ${s}</span>`).join("<br/>") : '<span class="muted">None</span>'}
        </div>
        <div class="skills-col">
          <h4>Missing Skills</h4>
          ${c.missing_skills.length ? c.missing_skills.map((s) => `<span class="tag-bad">✕ ${s}</span>`).join("<br/>") : '<span class="muted">None</span>'}
        </div>
      </div>
    `;
    container.appendChild(card);
  });
  document.getElementById("resultsCard").style.display = "block";
}
