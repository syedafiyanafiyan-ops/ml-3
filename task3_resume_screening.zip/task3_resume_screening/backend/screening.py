"""
Resume / Candidate Screening System - core engine.

Approach
--------
1. Text cleaning & parsing: lowercase, strip punctuation, tokenize.
2. Skill extraction: match resume/job-description text against a curated
   skills taxonomy (easily extendable). This is a transparent, explainable
   alternative to a black-box NER model and needs no extra downloads -
   the README explains how to swap in spaCy's NER/PhraseMatcher for a more
   advanced version.
3. Matching & ranking: combines two signals into one score per candidate:
      a) skill overlap  = (# matched required skills) / (# required skills)
      b) TF-IDF cosine similarity between the full resume text and the job
         description, capturing context beyond an exact keyword list
   final_score = 0.65 * skill_overlap + 0.35 * text_similarity
4. Skill gap identification: required skills mentioned in the job
   description but not found anywhere in the resume.
"""

import re
import string

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# A curated, extendable skills taxonomy. Add more terms/synonyms as needed.
SKILLS_TAXONOMY = {
    "python": ["python"],
    "sql": ["sql", "mysql", "postgresql", "postgres", "snowflake", "t-sql"],
    "excel": ["excel", "spreadsheets"],
    "power bi": ["power bi", "powerbi"],
    "tableau": ["tableau"],
    "machine learning": ["machine learning", "ml", "scikit-learn", "sklearn"],
    "deep learning": ["deep learning", "neural network", "tensorflow", "pytorch"],
    "statistics": ["statistics", "statistical analysis"],
    "a/b testing": ["a/b testing", "ab testing", "a-b testing"],
    "data visualization": ["data visualization", "dashboards", "dashboard"],
    "communication": ["communication", "presentation skills", "presenting"],
    "aws": ["aws", "amazon web services"],
    "azure": ["azure"],
    "gcp": ["gcp", "google cloud"],
    "docker": ["docker"],
    "kubernetes": ["kubernetes", "k8s"],
    "java": ["java"],
    "go": [" go ", "golang"],
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "git": ["git", "github", "version control"],
    "rest apis": ["rest api", "rest apis", "restful"],
}


def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"[\r\n]+", " ", text)
    return text


def extract_skills(text: str):
    """Returns the set of taxonomy skills found in the given text."""
    cleaned = f" {clean_text(text)} "
    found = set()
    for canonical, synonyms in SKILLS_TAXONOMY.items():
        for syn in synonyms:
            if syn in cleaned:
                found.add(canonical)
                break
    return found


def extract_required_skills(job_description: str):
    """
    Skills explicitly present in the job description are treated as
    "required" for matching purposes.
    """
    return extract_skills(job_description)


def score_candidate(resume_text: str, job_description: str, required_skills: set):
    resume_skills = extract_skills(resume_text)
    matched = sorted(resume_skills & required_skills)
    missing = sorted(required_skills - resume_skills)

    skill_overlap = len(matched) / len(required_skills) if required_skills else 0.0

    # TF-IDF cosine similarity between full resume and job description text
    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        tfidf = vectorizer.fit_transform([clean_text(job_description), clean_text(resume_text)])
        text_similarity = float(cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0])
    except ValueError:
        text_similarity = 0.0

    final_score = 0.65 * skill_overlap + 0.35 * text_similarity

    return {
        "matched_skills": matched,
        "missing_skills": missing,
        "skill_overlap_pct": round(skill_overlap * 100, 1),
        "text_similarity_pct": round(text_similarity * 100, 1),
        "final_score_pct": round(final_score * 100, 1),
    }


def rank_candidates(job_description: str, resumes: list):
    """
    resumes: list of {"name": str, "text": str}
    Returns a ranked list (highest score first) with full scoring breakdown.
    """
    required_skills = extract_required_skills(job_description)
    results = []

    for resume in resumes:
        name = resume.get("name", "Unnamed Candidate")
        text = resume.get("text", "")
        if not text.strip():
            continue
        scoring = score_candidate(text, job_description, required_skills)
        results.append({"name": name, **scoring})

    results.sort(key=lambda r: r["final_score_pct"], reverse=True)
    for i, r in enumerate(results, start=1):
        r["rank"] = i

    return {
        "required_skills": sorted(required_skills),
        "candidates": results,
    }
