"""
Resume / Candidate Screening System - Flask backend.

Endpoints
---------
GET  /api/health                -> health check
GET  /api/sample-data           -> bundled sample job description + resumes
POST /api/screen                -> body: {"job_description": "...",
                                            "resumes": [{"name": "...", "text": "..."}]}
                                    returns ranked candidates with scores & skill gaps
POST /api/screen/upload         -> multipart/form-data: job_description (text field)
                                    + one or more files under "resumes" (.txt)
"""

import os

from flask import Flask, jsonify, request
from flask_cors import CORS

from screening import rank_candidates

app = Flask(__name__)
CORS(app)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAMPLE_DIR = os.path.join(BASE_DIR, "sample_data")
RESUMES_DIR = os.path.join(SAMPLE_DIR, "resumes")
JD_PATH = os.path.join(SAMPLE_DIR, "job_description.txt")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "resume-screening-api"})


@app.get("/api/sample-data")
def sample_data():
    with open(JD_PATH, encoding="utf-8") as f:
        job_description = f.read()

    resumes = []
    for fname in sorted(os.listdir(RESUMES_DIR)):
        if fname.endswith(".txt"):
            with open(os.path.join(RESUMES_DIR, fname), encoding="utf-8") as f:
                resumes.append({"name": fname.replace("candidate_", "").replace(".txt", "").replace("_", " ").title(), "text": f.read()})

    return jsonify({"job_description": job_description, "resumes": resumes})


@app.post("/api/screen")
def screen():
    payload = request.get_json(force=True, silent=True) or {}
    job_description = payload.get("job_description", "").strip()
    resumes = payload.get("resumes", [])

    if not job_description:
        return jsonify({"error": "Field 'job_description' is required."}), 400
    if not resumes:
        return jsonify({"error": "Field 'resumes' (list of {name, text}) is required."}), 400

    try:
        result = rank_candidates(job_description, resumes)
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 400


@app.post("/api/screen/upload")
def screen_upload():
    job_description = request.form.get("job_description", "").strip()
    files = request.files.getlist("resumes")

    if not job_description:
        return jsonify({"error": "Form field 'job_description' is required."}), 400
    if not files:
        return jsonify({"error": "Upload one or more resume files under field 'resumes'."}), 400

    resumes = []
    for file in files:
        text = file.read().decode("utf-8", errors="ignore")
        resumes.append({"name": file.filename, "text": text})

    try:
        result = rank_candidates(job_description, resumes)
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 400


if __name__ == "__main__":
    app.run(debug=True, port=5002)
